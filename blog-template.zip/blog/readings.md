---
layout: page
title: Current Readings
permalink: /readings/
---

## What I'm reading right now

- **Book Title 1** — a quick note on what you think so far
- **Book Title 2** — same

## Recently finished

- **Book Title** — short review or rating

_Update this page whenever your reading list changes, or turn each book into its own post with the `reading` category._
