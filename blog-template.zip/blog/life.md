---
layout: page
title: Life Stuff
permalink: /life/
---

## Life Updates

This is where the everyday stuff goes — thoughts, updates, whatever's on your mind.

Posts tagged `life` will show up here if you set up the listing (see note below).
