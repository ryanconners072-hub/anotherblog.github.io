# My Jekyll Blog

## How to publish this

1. Create a repo on GitHub named `yourusername.github.io`
2. Upload ALL these files/folders to the repo root, keeping the folder structure:
   - `_config.yml`
   - `index.md`
   - `readings.md`, `life.md`, `games.md`, `fitness.md`
   - `_posts/` folder (contains your blog posts)
3. In the repo, go to **Settings → Pages** → set Source to `main` branch, root folder
4. Wait 1–2 minutes, then visit `https://yourusername.github.io`

## How to add a new post

Create a new file in `_posts/` named like:
`YYYY-MM-DD-post-title.md`

With this at the top:
```
---
layout: post
title: "Your Title"
date: YYYY-MM-DD
categories: life   # or games, readings, fitness
---

Your content here in Markdown.
```

## How to edit the tabs

Just edit `readings.md`, `life.md`, `games.md`, or `fitness.md` directly — they're plain Markdown.

## Notes

- The tabs appear automatically because `_config.yml` lists them under `header_pages`
- No need to install anything locally — GitHub builds the site for you on every push
- If you want to preview locally, install Ruby + Jekyll and run `bundle exec jekyll serve`
